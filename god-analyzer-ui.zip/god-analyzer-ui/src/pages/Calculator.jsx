import React, { useState, useMemo } from 'react';
import { Line } from 'react-chartjs-2';

function CalcInput({ label, value, onChange, prefix, suffix, step = '0.01', hint }) {
  return (
    <div className="form-group" style={{ marginBottom: 0 }}>
      <label className="form-label">{label}</label>
      <div style={{ position: 'relative', display: 'flex', alignItems: 'center' }}>
        {prefix && <span style={{ position: 'absolute', left: 10, color: 'var(--text-2)', fontSize: 11, pointerEvents: 'none' }}>{prefix}</span>}
        <input
          className="form-input"
          type="number"
          step={step}
          value={value}
          onChange={e => onChange(parseFloat(e.target.value) || 0)}
          style={{ paddingLeft: prefix ? 28 : 10, paddingRight: suffix ? 28 : 10 }}
        />
        {suffix && <span style={{ position: 'absolute', right: 10, color: 'var(--text-2)', fontSize: 11, pointerEvents: 'none' }}>{suffix}</span>}
      </div>
      {hint && <div style={{ fontSize: 10, color: 'var(--text-3)', marginTop: 3 }}>{hint}</div>}
    </div>
  );
}

function ResultRow({ label, value, accent, large }) {
  return (
    <div style={{
      display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      padding: '10px 16px',
      borderBottom: '1px solid var(--border)',
      background: 'transparent'
    }}>
      <span style={{ fontSize: large ? 13 : 11, color: 'var(--text-2)', letterSpacing: '0.06em' }}>{label}</span>
      <span style={{
        fontFamily: 'var(--font-mono)',
        fontSize: large ? 18 : 13,
        fontWeight: large ? 700 : 400,
        color: accent || 'var(--text-0)'
      }}>{value}</span>
    </div>
  );
}

export default function Calculator() {
  // === RATE & PROFIT CALCULATOR ===
  const [capital, setCapital] = useState(240);
  const [sellRate, setSellRate] = useState(633.26);
  const [buyRate, setBuyRate] = useState(629.89);
  const [cyclesPerDay, setCyclesPerDay] = useState(8);
  const [isPm, setIsPm] = useState(true);

  // === P2P PROFILE CALCULATOR ===
  const [currentOrders, setCurrentOrders] = useState(150);
  const [currentBTC30, setCurrentBTC30] = useState(0.5);
  const [currentBTCTotal, setCurrentBTCTotal] = useState(2);
  const [targetOrders, setTargetOrders] = useState(450);
  const [targetBTC30, setTargetBTC30] = useState(2);
  const [targetBTCTotal, setTargetBTCTotal] = useState(2);

  // === COMMISSION CALCULATOR ===
  const [commUSDT, setCommUSDT] = useState(100);
  const [commType, setCommType] = useState('buy');
  const [commPM, setCommPM] = useState(true);

  const rateCalc = useMemo(() => {
    if (sellRate <= 0 || buyRate <= 0 || capital <= 0) return null;
    const ganancia = (sellRate - buyRate) / buyRate;
    const sellMonto = capital * sellRate;
    const buyMonto = 20 * buyRate;
    const comBuy = 0.0025 + (isPm ? 0.003 : 0);
    const comSell = 0.0025;
    const profitPerCycle = capital * ganancia - capital * (comBuy + comSell);
    const profitTotal = profitPerCycle * cyclesPerDay;
    const profitMonth = profitTotal * 30;
    const tasaMinima = sellRate;
    return { ganancia, sellMonto, buyMonto, profitPerCycle, profitTotal, profitMonth, tasaMinima };
  }, [capital, sellRate, buyRate, cyclesPerDay, isPm]);

  const profileCalc = useMemo(() => {
    const ordersGap = targetOrders - currentOrders;
    const btc30Gap = targetBTC30 - currentBTC30;
    const btcTotalGap = targetBTCTotal - currentBTCTotal;

    const ordersPerDay = 10;
    const daysForOrders = ordersGap > 0 ? ordersGap / ordersPerDay : 0;
    const daysForBTC30 = btc30Gap > 0 ? btc30Gap / (currentBTC30 / 30) : 0;
    const daysForBTCTotal = btcTotalGap > 0 ? btcTotalGap / (currentBTCTotal / 90) : 0;

    const maxDays = Math.max(daysForOrders, daysForBTC30, daysForBTCTotal);
    return { ordersGap, btc30Gap, btcTotalGap, daysForOrders, daysForBTC30, daysForBTCTotal, maxDays };
  }, [currentOrders, currentBTC30, currentBTCTotal, targetOrders, targetBTC30, targetBTCTotal]);

  const commCalc = useMemo(() => {
    const baseRate = 0.0025;
    const pmExtra = 0.003;
    const rate = commType === 'buy' ? baseRate + (commPM ? pmExtra : 0) : baseRate;
    const comm = commUSDT * rate;
    const net = commUSDT - comm;
    return { rate, comm, net };
  }, [commUSDT, commType, commPM]);

  // Projection chart
  const projectionData = useMemo(() => {
    if (!rateCalc) return null;
    const days = Array.from({ length: 31 }, (_, i) => i);
    return {
      labels: days.map(d => `D${d}`),
      datasets: [
        {
          label: 'Profit Acumulado USDT',
          data: days.map(d => parseFloat((rateCalc.profitTotal * d).toFixed(4))),
          borderColor: '#00e5a0', backgroundColor: 'rgba(0,229,160,0.08)',
          fill: true, tension: 0.4, pointRadius: 2
        },
        {
          label: 'Capital USDT',
          data: days.map(() => capital),
          borderColor: '#5f7399', borderDash: [4, 4],
          backgroundColor: 'transparent', tension: 0, pointRadius: 0
        }
      ]
    };
  }, [rateCalc, capital]);

  const OPTS = {
    responsive: true, maintainAspectRatio: false,
    plugins: {
      legend: { display: true, labels: { color: '#a0aec0', font: { family: "'Space Mono'", size: 10 } } },
      tooltip: { mode: 'index', intersect: false }
    },
    scales: {
      x: { grid: { color: '#1c253d' }, ticks: { color: '#5f7399', font: { family: "'Space Mono'", size: 10 } } },
      y: { grid: { color: '#1c253d' }, ticks: { color: '#5f7399', font: { family: "'Space Mono'", size: 10 } } }
    }
  };

  const fVES = n => n.toLocaleString('es-VE', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const fU = n => n.toFixed(4);

  return (
    <div className="page">
      <div className="page-header">
        <div className="page-title">Calculadora P2P</div>
        <div className="page-sub">TASAS · GANANCIA · PERFIL · COMISIONES</div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 16, marginBottom: 16 }}>
        {/* Rate Calculator */}
        <div style={{ gridColumn: '1 / 3' }}>
          <div className="chart-card">
            <div style={{ display: 'flex', gap: 24 }}>
              <div style={{ flex: 1 }}>
                <div className="chart-title" style={{ marginBottom: 16 }}>◈ Calculadora de Tasas y Ganancia</div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 12 }}>
                  <CalcInput label="Capital (USDT)" value={capital} onChange={setCapital} step="1" hint="Tu inventario de USDT" />
                  <CalcInput label="Ciclos al Día" value={cyclesPerDay} onChange={setCyclesPerDay} step="1" hint="Venta + recompra = 1 ciclo" />
                  <CalcInput label="Tasa Venta" value={sellRate} onChange={setSellRate} prefix="Bs" step="0.01" hint="Precio al que vendes USDT" />
                  <CalcInput label="Tasa Compra" value={buyRate} onChange={setBuyRate} prefix="Bs" step="0.01" hint="Precio al que compras USDT" />
                </div>
                <div className="checkbox-row" style={{ marginBottom: 16 }}>
                  <input type="checkbox" id="calc-pm" checked={isPm} onChange={e => setIsPm(e.target.checked)} />
                  <label htmlFor="calc-pm" style={{ fontSize: 12 }}>Incluir comisión Pago Móvil (+0.30%)</label>
                </div>
              </div>
              <div style={{ flex: 1, background: 'var(--bg-1)', borderRadius: 'var(--radius-md)', overflow: 'hidden', alignSelf: 'flex-start' }}>
                {rateCalc && <>
                  <ResultRow label="Ganancia por operación" value={`${(rateCalc.ganancia * 100).toFixed(4)}%`} accent="var(--green)" />
                  <ResultRow label="Monto Venta Lote" value={`Bs. ${fVES(rateCalc.sellMonto)}`} />
                  <ResultRow label="Monto Compra 20 USDT" value={`Bs. ${fVES(rateCalc.buyMonto)}`} />
                  <ResultRow label="Tasa Mínima" value={`Bs. ${fVES(rateCalc.tasaMinima)}`} accent="var(--amber)" />
                  <ResultRow label="Ganancia / Ciclo" value={`${fU(rateCalc.profitPerCycle)} USDT`} accent="var(--green)" />
                  <ResultRow label="Ganancia Total Diaria" value={`${fU(rateCalc.profitTotal)} USDT`} accent="var(--green)" large />
                  <ResultRow label="Proyección Mensual" value={`${fU(rateCalc.profitMonth)} USDT`} accent="var(--purple)" large />
                </>}
              </div>
            </div>
            {projectionData && (
              <div style={{ marginTop: 20 }}>
                <div className="chart-title">Proyección 30 días de profit acumulado</div>
                <div style={{ height: 160 }}><Line data={projectionData} options={OPTS} /></div>
              </div>
            )}
          </div>
        </div>

        {/* Commission Calculator */}
        <div>
          <div className="chart-card" style={{ height: '100%' }}>
            <div className="chart-title" style={{ marginBottom: 16 }}>⟁ Calculadora de Comisión</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              <CalcInput label="Cantidad USDT" value={commUSDT} onChange={setCommUSDT} step="0.01" />
              <div className="form-group">
                <label className="form-label">Tipo de Orden</label>
                <select className="form-select" value={commType} onChange={e => setCommType(e.target.value)}>
                  <option value="buy">Compra</option>
                  <option value="sell">Venta</option>
                </select>
              </div>
              <div className="checkbox-row">
                <input type="checkbox" id="comm-pm" checked={commPM} onChange={e => setCommPM(e.target.checked)} disabled={commType === 'sell'} />
                <label htmlFor="comm-pm" style={{ fontSize: 11 }}>Pago Móvil (+0.30%)</label>
              </div>
            </div>
            <div style={{ background: 'var(--bg-1)', borderRadius: 'var(--radius-md)', overflow: 'hidden', marginTop: 16 }}>
              <ResultRow label="Tasa comisión" value={`${(commCalc.rate * 100).toFixed(3)}%`} />
              <ResultRow label="Comisión USDT" value={`${commCalc.comm.toFixed(4)} USDT`} accent="var(--red)" />
              <ResultRow label="Neto recibido" value={`${commCalc.net.toFixed(4)} USDT`} accent="var(--green)" large />
            </div>
          </div>
        </div>
      </div>

      {/* Profile Calculator */}
      <div className="chart-card">
        <div className="chart-title" style={{ marginBottom: 20 }}>◎ Calculadora de Perfil P2P — ¿Cuánto me falta?</div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
          <div>
            <div style={{ fontSize: 11, color: 'var(--text-2)', letterSpacing: '0.1em', marginBottom: 12 }}>PERFIL ACTUAL</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              <CalcInput label="Total de Órdenes" value={currentOrders} onChange={setCurrentOrders} step="1" />
              <CalcInput label="Volumen BTC últimos 30 días" value={currentBTC30} onChange={setCurrentBTC30} step="0.01" suffix="BTC" />
              <CalcInput label="Volumen BTC total de cuenta" value={currentBTCTotal} onChange={setCurrentBTCTotal} step="0.01" suffix="BTC" />
            </div>
          </div>
          <div>
            <div style={{ fontSize: 11, color: 'var(--text-2)', letterSpacing: '0.1em', marginBottom: 12 }}>PERFIL A LOGRAR</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              <CalcInput label="Órdenes Objetivo" value={targetOrders} onChange={setTargetOrders} step="1" />
              <CalcInput label="BTC 30 días Objetivo" value={targetBTC30} onChange={setTargetBTC30} step="0.01" suffix="BTC" />
              <CalcInput label="BTC Total Objetivo" value={targetBTCTotal} onChange={setTargetBTCTotal} step="0.01" suffix="BTC" />
            </div>
          </div>
        </div>

        <div style={{ background: 'var(--bg-1)', borderRadius: 'var(--radius-md)', overflow: 'hidden', marginTop: 20 }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 1fr', borderBottom: '1px solid var(--border)' }}>
            {[
              { label: 'Gap Órdenes', value: `+${profileCalc.ordersGap}`, days: `~${profileCalc.daysForOrders.toFixed(1)} días` },
              { label: 'Gap BTC 30d', value: `+${profileCalc.btc30Gap.toFixed(2)} BTC`, days: `~${profileCalc.daysForBTC30.toFixed(1)} días` },
              { label: 'Gap BTC Total', value: `+${profileCalc.btcTotalGap.toFixed(2)} BTC`, days: `~${profileCalc.daysForBTCTotal.toFixed(1)} días` },
              { label: 'TIEMPO TOTAL', value: `${profileCalc.maxDays.toFixed(1)} días`, days: '', bold: true },
            ].map((item, i) => (
              <div key={i} style={{ padding: '16px 18px', borderRight: i < 3 ? '1px solid var(--border)' : 'none' }}>
                <div style={{ fontSize: 10, color: 'var(--text-2)', letterSpacing: '0.1em', marginBottom: 6 }}>{item.label}</div>
                <div style={{ fontSize: item.bold ? 22 : 16, fontWeight: 700, color: item.bold ? 'var(--amber)' : 'var(--text-0)', fontFamily: 'var(--font-mono)' }}>{item.value}</div>
                {item.days && <div style={{ fontSize: 10, color: 'var(--text-3)', marginTop: 4 }}>{item.days}</div>}
              </div>
            ))}
          </div>
          <div style={{ padding: '10px 16px', fontSize: 10, color: 'var(--text-3)' }}>
            * Estimado basado en ritmo actual. Las métricas BTC se calculan en proporción al historial disponible.
          </div>
        </div>
      </div>
    </div>
  );
}

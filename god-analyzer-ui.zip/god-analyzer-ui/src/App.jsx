import React, { useState, useCallback } from 'react';
import { enrichExpediente, EMPTY_EXPEDIENTE, validateExpediente, computeCycles, computeStats } from './utils/expediente';
import Dashboard from './pages/Dashboard';
import OrdersTable from './pages/OrdersTable';
import CyclesView from './pages/CyclesView';
import Calculator from './pages/Calculator';
import './App.css';

const NAV = [
  { id: 'dashboard', label: 'Dashboard', icon: '◈' },
  { id: 'orders', label: 'Órdenes', icon: '≡' },
  { id: 'cycles', label: 'Ciclos', icon: '◎' },
  { id: 'calculator', label: 'Calculadora', icon: '⟁' },
];

export default function App() {
  const [view, setView] = useState('dashboard');
  const [expediente, setExpediente] = useState(() => enrichExpediente({ ...EMPTY_EXPEDIENTE }));
  const [toast, setToast] = useState(null);

  const showToast = useCallback((msg, type = 'ok') => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 2800);
  }, []);

  const updateOrders = useCallback((newOrders) => {
    setExpediente(prev => {
      const cycles = computeCycles(newOrders);
      const stats = computeStats(newOrders);
      return { ...prev, orders: newOrders, cycles, stats };
    });
  }, []);

  const handleUpload = useCallback((e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const data = JSON.parse(ev.target.result);
        if (!validateExpediente(data)) throw new Error('Formato inválido');
        setExpediente(enrichExpediente(data));
        showToast(`✓ Expediente cargado — ${data.orders?.length || 0} órdenes`, 'ok');
      } catch (err) {
        showToast('✗ Error al parsear JSON: ' + err.message, 'err');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  }, [showToast]);

  const handleDownload = useCallback(() => {
    const clean = {
      chat_id: expediente.chat_id,
      date: expediente.date,
      orders: expediente.orders.map(({ id, ...rest }) => rest),
      cycles: expediente.cycles,
      stats: expediente.stats,
      bank_receipts: expediente.bank_receipts || []
    };
    const blob = new Blob([JSON.stringify(clean, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `expediente_${expediente.chat_id || 'export'}_${expediente.date || 'hoy'}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('✓ JSON descargado', 'ok');
  }, [expediente, showToast]);

  const PAGE = { dashboard: Dashboard, orders: OrdersTable, cycles: CyclesView, calculator: Calculator };
  const CurrentPage = PAGE[view];

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="sidebar-brand">
          <span className="brand-icon">⬡</span>
          <div>
            <div className="brand-title">GOD ANALYZER</div>
            <div className="brand-sub">BETA</div>
          </div>
        </div>
        <nav className="sidebar-nav">
          {NAV.map(n => (
            <button
              key={n.id}
              className={`nav-btn ${view === n.id ? 'active' : ''}`}
              onClick={() => setView(n.id)}
            >
              <span className="nav-icon">{n.icon}</span>
              <span>{n.label}</span>
            </button>
          ))}
        </nav>
        <div className="sidebar-io">
          <div className="exp-meta">
            <div className="exp-id">{expediente.chat_id || 'Sin expediente'}</div>
            <div className="exp-date">{expediente.date}</div>
          </div>
          <label className="io-btn upload-btn">
            ↑ Cargar JSON
            <input type="file" accept=".json" onChange={handleUpload} hidden />
          </label>
          <button className="io-btn download-btn" onClick={handleDownload}>
            ↓ Exportar JSON
          </button>
        </div>
      </aside>

      <main className="main-content">
        <CurrentPage
          expediente={expediente}
          onUpdateOrders={updateOrders}
          showToast={showToast}
        />
      </main>

      {toast && (
        <div className={`toast toast-${toast.type}`}>{toast.msg}</div>
      )}
    </div>
  );
}

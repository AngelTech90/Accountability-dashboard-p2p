#!/usr/bin/env bash
# ============================================================
# God Analyzer UI — Setup, Build & Deploy
# Usage:
#   ./setup.sh            # install deps + start dev server
#   ./setup.sh build      # production build
#   ./setup.sh deploy     # build + deploy to GitHub Pages
#   ./setup.sh clean      # remove node_modules and build
# ============================================================

set -e

REPO_NAME="god-analyzer-ui"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Colors
GREEN="\033[0;32m"
BLUE="\033[0;34m"
AMBER="\033[0;33m"
RED="\033[0;31m"
RESET="\033[0m"

log()  { echo -e "${BLUE}[GOD]${RESET} $1"; }
ok()   { echo -e "${GREEN}[OK]${RESET} $1"; }
warn() { echo -e "${AMBER}[WARN]${RESET} $1"; }
err()  { echo -e "${RED}[ERR]${RESET} $1"; exit 1; }

# ── Check node & npm ─────────────────────────────────────────
check_deps() {
  log "Checking Node.js and npm..."
  if ! command -v node &>/dev/null; then
    err "Node.js not found. Install from https://nodejs.org (v18+ recommended)"
  fi
  NODE_VER=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
  if [ "$NODE_VER" -lt 16 ]; then
    err "Node.js v16+ required (found $(node -v)). Please update."
  fi
  ok "Node.js $(node -v) / npm $(npm -v)"
}

# ── Install dependencies ──────────────────────────────────────
install() {
  log "Installing dependencies..."
  cd "$SCRIPT_DIR"
  npm install --legacy-peer-deps
  # Node 18+/react-scripts 5 ajv peer-dep fix (needed for Node 22)
  npm install ajv@^8.0.0 --legacy-peer-deps --save 2>/dev/null || true
  ok "All dependencies installed"
}

# ── Dev server ────────────────────────────────────────────────
dev() {
  check_deps
  if [ ! -d "$SCRIPT_DIR/node_modules" ]; then install; fi
  log "Starting development server at http://localhost:3000"
  cd "$SCRIPT_DIR"
  npm start
}

# ── Production build ─────────────────────────────────────────
build() {
  check_deps
  if [ ! -d "$SCRIPT_DIR/node_modules" ]; then install; fi
  log "Building production bundle..."
  cd "$SCRIPT_DIR"
  GENERATE_SOURCEMAP=false npm run build
  ok "Build complete → ./build/"
  echo ""
  echo "  To serve locally:  npx serve -s build"
  echo "  To deploy:         ./setup.sh deploy"
}

# ── GitHub Pages deploy ───────────────────────────────────────
deploy() {
  check_deps
  if [ ! -d "$SCRIPT_DIR/node_modules" ]; then install; fi

  # Check git remote
  if ! git -C "$SCRIPT_DIR" remote get-url origin &>/dev/null; then
    warn "No git remote 'origin' found."
    warn "Set it with: git remote add origin https://github.com/YOUR_USER/${REPO_NAME}.git"
    warn "Then run: ./setup.sh deploy"
    exit 1
  fi

  REMOTE_URL=$(git -C "$SCRIPT_DIR" remote get-url origin)
  log "Remote: $REMOTE_URL"

  # Extract username from remote URL (works for https and ssh)
  GH_USER=$(echo "$REMOTE_URL" | sed -E 's|.*github\.com[:/]([^/]+)/.*|\1|')
  REPO=$(echo "$REMOTE_URL" | sed -E 's|.*github\.com[:/][^/]+/([^/.]+).*|\1|')

  log "Deploying to https://${GH_USER}.github.io/${REPO}/"

  # Update homepage in package.json for correct asset paths
  if command -v python3 &>/dev/null; then
    python3 -c "
import json
with open('$SCRIPT_DIR/package.json') as f: pkg = json.load(f)
pkg['homepage'] = f'https://${GH_USER}.github.io/${REPO}'
with open('$SCRIPT_DIR/package.json', 'w') as f: json.dump(pkg, f, indent=2)
print('Updated homepage in package.json')
"
  fi

  cd "$SCRIPT_DIR"
  GENERATE_SOURCEMAP=false npm run build

  # Install gh-pages if not present
  if ! npx --no -- gh-pages --version &>/dev/null; then
    log "Installing gh-pages..."
    npm install --save-dev gh-pages
  fi

  npx gh-pages -d build
  ok "Deployed! Live in ~1 min at https://${GH_USER}.github.io/${REPO}/"
}

# ── Clean ─────────────────────────────────────────────────────
clean() {
  log "Cleaning build artifacts..."
  rm -rf "$SCRIPT_DIR/node_modules" "$SCRIPT_DIR/build" "$SCRIPT_DIR/.cache"
  ok "Cleaned node_modules, build, .cache"
}

# ── Git init helper ───────────────────────────────────────────
git_init() {
  cd "$SCRIPT_DIR"
  if [ ! -d ".git" ]; then
    git init
    git add .
    git commit -m "feat: God Analyzer UI initial commit"
    ok "Git repo initialized with initial commit"
    echo ""
    echo "Next steps:"
    echo "  1. Create repo on GitHub: https://github.com/new"
    echo "  2. git remote add origin https://github.com/YOUR_USER/${REPO_NAME}.git"
    echo "  3. git push -u origin main"
    echo "  4. ./setup.sh deploy"
  else
    ok "Git repo already initialized"
  fi
}

# ── .gitignore ───────────────────────────────────────────────
write_gitignore() {
  cat > "$SCRIPT_DIR/.gitignore" << 'EOF'
node_modules/
build/
.cache/
.env.local
.env.development.local
.env.test.local
.env.production.local
npm-debug.log*
yarn-debug.log*
yarn-error.log*
.DS_Store
EOF
  ok "Created .gitignore"
}

# ── Main ─────────────────────────────────────────────────────
CMD="${1:-dev}"

echo ""
echo -e "${GREEN}⬡ GOD ANALYZER UI — Setup Script${RESET}"
echo -e "${BLUE}─────────────────────────────────${RESET}"
echo ""

case "$CMD" in
  dev)        write_gitignore; dev ;;
  install)    check_deps; install ;;
  build)      build ;;
  deploy)     deploy ;;
  clean)      clean ;;
  git-init)   git_init ;;
  *)
    echo "Usage: ./setup.sh [dev|install|build|deploy|clean|git-init]"
    echo ""
    echo "  dev       — Install deps + start dev server (default)"
    echo "  install   — Install npm dependencies only"
    echo "  build     — Production build to ./build/"
    echo "  deploy    — Build + deploy to GitHub Pages"
    echo "  clean     — Remove node_modules and build"
    echo "  git-init  — Initialize git repo with first commit"
    ;;
esac
